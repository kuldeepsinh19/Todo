// import logo from './logo.svg';
// import './style.css';

// import Todo from "./components/Todo";
// import Okokok from "./components/Okokok";
import Todo from "./components/Todo";
// import Temp from "./components/weather/temp";

function App() {
  return (
<>
{/* <Temp/ */}
{/* <Okokok/> */}
<Todo/>
</>
  );
}

export default App;
